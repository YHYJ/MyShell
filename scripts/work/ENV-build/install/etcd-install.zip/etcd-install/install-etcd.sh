#!/bin/bash

:<<!
Author: YJ
Email: yj1516268@outlook.com
Created Date: 2018-10-24 14:15:56


!


timeout=5

path=/usr/bin/
name=etcd
pg=$path$name

ask() {
  # $REPLY 是默认的 read 命令保存参数的变量
  while true; do
    read -t "$timeout" -r -p "$1"
    REPLY=${REPLY:-Y}
    echo
    if [[ "$REPLY" =~ ^[Yy] ]]; then
      return 0
    elif [[ "$REPLY" =~ ^[Nn] ]]; then
      return 1
    else
      echo
      echo "[Hint]: 请输入 Y/y 或 N/n."
    fi
  done
}

install() {
  echo
  echo "[Info]: 正在安装."
  echo
  
  cd ./"$name" || exit
  cp ./"$name" "$path"
  cp ./etcdctl "$path"
  cp ./"$name".service /etc/systemd/system/
  
  chmod a+x "$pg"
  chmod a+x "$path"etcdctl
  
  mkdir /etc/"$name" > /dev/null
  cp ./"$name".conf /etc/"$name"
  
  mkdir /var/lib/"$name" > /dev/null
  
  systemctl daemon-reload
  if systemctl enable "$name" > /dev/null; then
    if systemctl start "$name"; then
      if systemctl status "$name" > /dev/null; then
        echo
        echo ">>>$name服务注册成功，服务已运行，已设置自启动."
        echo
      fi
    else
      echo -e "\\e[31m[Error]:\\e[0m $name服务启动失败，请查明."
      echo
    fi
  else
    echo -e "\\e[31m[Error]:\\e[0m $name设置自启动失败，请查明."
    echo
  fi

  echo ">>>$name安装成功."
  echo
}

register() {
  if systemctl is-enabled "$name" > /dev/null; then
    if systemctl is-active "$name" > /dev/null; then
      exit 0
    else
      if ask "[Ask]: 检测到$name服务未启动，是否启动它（y/n）？"; then
        echo
        echo "[Info]: 正在启动$name服务"
        echo "......"
        echo
        if systemctl start "$name"; then
          echo ">>>$name服务启动成功."
          echo
        else 
          echo -e "\\e[31m[Error]:\\e[0m $name服务启动失败，请查明."
          echo
        fi
      fi
    fi
  else
    if ask "[Ask]: 检测到$name服务未注册，是否现在注册（y/n）？";then
      echo
      echo "[Info]: 正在注册服务"
      echo "......"
      echo
      systemctl daemon-reload
      if systemctl enable "$name" > /dev/null; then
        if systemctl start "$name"; then
          if systemctl status "$name" > /dev/null; then
            echo ">>>$name服务注册成功，服务已运行，已设置自启动."
            echo
          fi
        else
          echo -e "\\e[31m[Error]:\\e[0m $name服务启动失败，请查明."
          echo
        fi
      else
        echo -e "\\e[31m[Error]:\\e[0m $name设置自启动失败，请查明."
        echo
      fi
    else
      echo
      echo "[Bye]: 退出."
      echo
    fi
  fi
}

change() {
  # $1 是"对象+/-权限"，例如 a+x
  # $2 是操作对象
  chmod "$1" "$2"
}

uncompress() {
  echo "[Info]: 正在解压..."
  if unzip -n ./"$name".zip > /dev/null; then
    echo
    echo ">>> 解压完成."
  else
    echo
    echo "[Error]: 解压失败."
  fi
}


# main
if [[ ! -e "$pg" ]]; then
  echo
  echo -e "\\e[31m$name未安装.\\e[0m"
  echo
  if ask "[Ask]: 是否安装$name（Y/n）？"; then
    echo
    uncompress
    install
    register
  else
    echo
    echo "[Bye]: 退出."
    echo
  fi
elif [[ -e "$pg" && ! -x "$pg" ]]; then
  echo -e "\\e[31m$name已安装但不具备执行权限.\\e[0m"
  echo
  if ask "[Ask]: 是否赋予$name执行权限（y/n）？"; then
    change a+x $pg
    change a+x "$path"etcdctl
    
    register
  else
    echo
    echo "[Bye]: 退出."
    echo
  fi
else
  echo
  echo ">>>$name已安装."
  echo
  register
fi
