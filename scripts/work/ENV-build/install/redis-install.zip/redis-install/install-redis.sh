#!/bin/bash

:<<!
Author: YJ
Email: yj1516268@outlook.com
Created Date: 2018-11-16 17:35:10


!


timeout=5

path=/usr/local/bin/
name=redis
pg="$path$name"-server

ask() {
  # $REPLY 是默认的 read 命令保存参数的变量
  while true; do
    read -t "$timeout" -r -p "$1"
    REPLY=${REPLY:-Y}
    echo
    if [[ "$REPLY" =~ ^[Yy] ]]; then
      return 0
    elif [[ "$REPLY" =~ ^[Nn] ]]; then
      return 1
    else
      echo "[Hint]: 请输入 Y/y 或 N/n."
      echo
    fi
  done
}

progress() {
  # 等待提示
  # $1: 进程号
  # $2: 操作名
  # $3: 预估等待时间
  while ps -p "$1" > /dev/null; do
    for next in "-" "\\" "|" "/"; do
      tput sc
      echo -ne "[Progress]: 正在进行$2，大约需要$3... $next"
      sleep 0.1
      tput rc
    done
  done
  return 0
}

wait_finish() {
  # 等待后台命令执行完毕获取其退出状态
  # $1: 进程号
  # $2: 操作名称
  if wait "$1"; then
    echo
    echo
    echo ">>> $2完成."
    echo
  else
    echo
    echo
    echo "[Error]: $2失败."
    echo
  fi
}

uncompress() {
  # 解压
  unzip -n redis.zip > /dev/null &
  pid="$!"
  progress "$pid" "解压" "0.2s"
  wait_finish "$pid" "解压"
}

install() {
  # 安装
  cd ./"$name" || exit 1

  ## 1. make
  make &> /dev/null &
  pid="$!"
  progress "$pid" "make" "2min"
  wait_finish "$pid" "make"

  ## 2. make install
  make install &> /dev/null &
  pid="$!"
  progress "$pid" "make install" "30s"
  wait_finish "$pid" "make install"

  ## 3. Create service
  echo -n | ./utils/install_server.sh &> /dev/null &
  pid="$!"
  progress "$pid" "run script" "2s"
  wait_finish "$pid" "run script"

  ## 4. 退出并清理安装文件夹
  cd ..
  rm -rf ./"$name"
}

start_redis() {
  systemctl start redis_6379 > /dev/null &
  pid="$!"
  progress "$pid" "start redis" "1s"
  wait_finish "$pid" "start redis"
}


# main
  if [[ ! -e "$pg" && ! -e "/etc/init.d/redis_6379" ]]; then
  # 未安装
  echo
  echo -e "\\e[31m$name未安装.\\e[0m"
  echo
  if ask "[Ask]: 是否安装$name（Y/n）？"; then
    echo
    uncompress
    install
    start_redis
  else
    echo "[Bye]: 退出."
    echo
  fi
else
  echo
  echo ">>> $name已存在."
  echo
fi
