#!/bin/bash

:<<!
Author: YJ
Email: yj1516268@outlook.com
Created Date: 2018-11-16 15:21:05

Warning:
1. install() --> 2. make
  隐藏了警告和错误的输出，现在只会提示是否make成功不会显示失败的具体原因
!


timeout=5

py_install_path=/usr/local/python3/bin/python3
pip_install_path=/usr/local/python3/bin/pip3

exec_path=/usr/local/bin/
py=python3
pip=pip3
py_pkg=$exec_path$py
pip_pkg=$exec_path$pip

ask() {
  while true; do
    read -t "$timeout" -r -p "$1"
    REPLY=${REPLY:-Y}
    if [[ "$REPLY" =~ ^[Yy] ]]; then
      return 0
    elif [[ "$REPLY" =~ ^[Nn] ]]; then
      return 1
    else
      echo -e "\\e[34;4m[Hint]: 请输入 Y/y 或 N/n.\\e[0m"
    fi
  done
}

progress() {
  # 等待提示
  # $1: 进程号
  # $2: 操作名
  # $3: 预估等待时间
  while ps -p "$1" > /dev/null; do
    for next in "-" "\\" "|" "/"; do
      tput sc
      echo -ne "\\e[7m[Progress]: 正在进行$2，大约需要$3... $next\\e[0m"
      sleep 0.1
      tput rc
    done
  done
  return 0
}

wait_finish() {
  # 等待后台命令执行完毕获取其退出状态
  # $1: 进程号
  # $2: 操作名称
  if wait "$1"; then
    echo -e "\\e[32;1m>>> $2完成.\\e[0m"
  else
    echo "\\e[31;1;5m[Error]: $2失败.\\e[0m"
  fi
}

uncompress() {
  # 解压缩
  unzip -n ./Python-3.zip > /dev/null &
  pid="$!"
  progress "$pid" "解压" "2s"
  wait_finish "$pid" "解压"
}

check_and_install() {
  # 检查依赖是否齐全，否则安装
  required_by=("openssl-devel" "gcc")
  for require in ${required_by[*]}; do
    if ! rpm -q "$require" &> /dev/null; then
      echo -e "\\e[31;05m[Warning]: 正在安装依赖$require.\\e[0m"
      if yum -y localinstall ./requires/"$require"/*.rpm; then
        echo -e "\\e[32;1m>>> 安装成功.\\e[0m"
      else
        echo -e "\\e[31;1;5m[Error]: 安装失败.\\e[0m"
        exit 1
      fi
    fi
  done
}

install() {
  # 安装Python
  cd ./Python-3 || exit 1

  ## 1. configure
  ./configure --prefix=/usr/local/python3 > /dev/null &
  pid="$!"
  progress "$pid" "configure" "1min"
  wait_finish "$pid" "configure"

  ## 2. make
  make &> /dev/null &
  pid="$!"
  progress "$pid" "make" "6min"
  wait_finish "$pid" "make"

  ## 3. make install
  make install > /dev/null &
  pid="$!"
  progress "$pid" "make install" "1min"
  wait_finish "$pid" "make install"

  ## 3. 创建软链接到PATH路径
  echo "[Info]: 正在创建软链接..."
  ln -s "$py_install_path" "$py_pkg" > /dev/null &
  pid="$!"
  wait_finish "$pid" "python3软链接创建"

  ln -s "$pip_install_path" "$pip_pkg" > /dev/null &
  pid="$!"
  wait_finish "$pid" "pip3软链接创建"

  ## 4. 退出并清理安装文件夹
  cd ..
  rm -rf ./Python-3
}


# main
if [[ ! -e "$py_pkg" && ! -d /usr/local/python3 ]]; then
  # 未安装
  echo -e "\\e[35m$py未安装.\\e[0m"
  if ask $"\e[36m[Ask]: 是否/更新安装依赖？(Y/n)\e[0m"; then
    check_and_install
    if ask $'\e[36m[Ask]: 是否安装$py ？(Y/n)\e[0m'; then
      uncompress
      install
    else
      echo -e "\\e[33m[Bye]: 退出.\\e[0m"
    fi
  else
    echo -e "\\e[33m[Bye]: 退出.\\e[0m"
  fi
else
  echo -e "\\e[32;1m>>> $py已存在.\\e[0m"
fi
