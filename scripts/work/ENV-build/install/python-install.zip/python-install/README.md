- 安装文件夹需要是zip格式的压缩包
- 压缩包名为Python-#.zip，# = Python大版本号

