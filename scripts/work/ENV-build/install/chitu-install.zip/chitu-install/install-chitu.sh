#!/bin/bash

:<<!
Author: YJ
Email: yj1516268@outlook.com
Created Date: 2018-11-20 09:38:58


!


timeout=5

ask() {
  while true; do
    read -t "$timeout" -r -p "$1"
    REPLY=${REPLY:-Y}
    echo
    if [[ "$REPLY" =~ ^[Yy] ]]; then
      return 0
    elif [[ "$REPLY" =~ ^[Nn] ]]; then
      return 1
    else
      echo "[Hint]: 请输入 Y/y 或 N/n."
      echo
    fi
  done
}

wait_finish() {
  # 等待后台命令执行完毕获取其退出状态
  # $1: 进程号
  # $2: 操作名
  if wait "$1"; then
    echo
    echo ">>> $2完成."
    echo
  else
    echo
    echo "[Error]: $2失败."
    echo
  fi
}

uncompress() {
  # 解压缩
  echo "[Info]: 正在解压chitu.zip..."
  unzip -n chitu.zip > /dev/null &
  pid="$!"
  wait_finish "$pid" "解压"

  echo "[Info]: 正在解压service.zip..."
  unzip -n service.zip > /dev/null &
  pid="$!"
  wait_finish "$pid" "解压"
}

register() {
  # 注册服务
  echo "[Info]: 正在注册chitu服务."
  systemctl daemon-reload
  systemctl enable chitu > /dev/null
  systemctl restart chitu > /dev/null &
  pid="$!"
  wait_finish "$pid" "注册"
}

install() {
  # 安装
  if [[ -d /usr/mabo ]]; then
    cp -r ./chitu /usr/mabo > /dev/null
    cp -v ./service/chitu.service /etc/systemd/system > /dev/null
    echo ">>> chitu安装成功."
    echo
    if ask "[Ask]: 是否现在启动chitu服务（Y/n）？"; then
      echo
      register
      echo ">>> chitu启动成功."
      echo
    else
      echo
      echo "[Bye]: 退出."
      echo
    fi
  else
    mkdir /usr/mabo
    cp -r ./chitu /usr/mabo > /dev/null
    cp -v ./service/chitu.service /etc/systemd/system > /dev/null
    echo ">>> chitu安装成功."
    if ask "[Ask]: 是否启动chitu服务（Y/n）？"; then
      register
      echo ">>> chitu启动成功."
      echo
    else
      echo
      echo "[Bye]: 退出."
      echo
    fi
  fi
}


# main
if [[ -d /usr/mabo/chitu && -f /etc/systemd/system/chitu.service ]]; then
  echo
  echo "[Info]: chitu及其service已存在."
  if systemctl status chitu; then
    echo
    echo "[Info]: chitu服务已启动."
    echo
  else
    echo
    if ask "[Ask]: 是否启动chitu服务（Y/n）？"; then
      echo
      systemctl restart chitu
      echo
      echo ">>> chitu启动成功."
      echo
    else
      echo
      echo "[Bye]: 退出."
    fi
  fi
else
  echo
  if ask "[Ask]: 是否安装chitu及其服务（Y/n）？"; then
    echo
    uncompress
    install
  else
    echo "[Bye]: 退出."
    echo
  fi
fi
