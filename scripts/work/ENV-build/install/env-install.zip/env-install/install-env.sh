#!/bin/bash

:<<!
Author: YJ
Email: yj1516268@outlook.com
Created Date: 2018-11-20 09:38:58


!


timeout=5

ask() {
  while true; do
    read -t "$timeout" -r -p "$1"
    REPLY=${REPLY:-Y}
    echo
    if [[ "$REPLY" =~ ^[Yy] ]]; then
      return 0
    elif [[ "$REPLY" =~ ^[Nn] ]]; then
      return 1
    else
      echo "[Hint]: 请输入 Y/y 或 N/n."
      echo
    fi
  done
}

wait_finish() {
  # 等待后台命令执行完毕获取其退出状态
  # $1: 进程号
  # $2: 操作名称
  if wait "$1"; then
    echo
    echo ">>> $2完成."
    echo
  else
    echo
    echo "[Error]: $2失败."
    echo
  fi
}

uncompress() {
  # 解压缩
  echo "[Info]: 正在解压..."
  unzip -n packages.zip > /dev/null &
  pid="$!"
  wait_finish "$pid" "解压"
}

install() {
  # 安装  
  echo "[Info]: 正在安装..."
  if yum -y localinstall ./packages/*.rpm > /dev/null; then
    echo
    echo ">>> 安装成功."
    echo
  else
    echo
    echo "[Error]: 安装失败."
    cd ..
    rm -rf ./packages
    echo
    exit 1
  fi

  rm -rf ./packages
}


# main
echo
if ask "[Ask]: 是否安装依赖包(rpm)（Y/n）？"; then
  uncompress
  install
else
  echo "[Bye]: 退出."
  echo
fi
